package investigacao.clue;

import net.minecraft.world.phys.Vec3;

/** Pinos (quadradinhos) e linhas retas entre eles, sem física. */
public final class ClueData {
    private ClueData() {}

    /** start = primeiro pino da corrente (vermelho); os demais são azuis. */
    public record Pin(Vec3 pos, Vec3 normal, boolean start) {
        public int color() { return start ? 0xD02020 : 0x2447D6; }
    }

    public record Link(Vec3 a, Vec3 b) {}
}
