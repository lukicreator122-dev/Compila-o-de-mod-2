package investigacao.clue;

import investigacao.Investigacao;
import investigacao.clue.ClueData.Link;
import investigacao.clue.ClueData.Pin;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.storage.LevelResource;
import net.minecraft.world.phys.Vec3;

/** Guarda pinos e linhas por dimensão em <mundo>/linhas_vermelhas.txt. */
public final class ClueStore {
    private static final Map<String, List<Pin>> PINS = new HashMap<>();
    private static final Map<String, List<Link>> LINKS = new HashMap<>();

    private ClueStore() {}

    private static Path file(MinecraftServer s) { return s.getWorldPath(LevelResource.ROOT).resolve("linhas_vermelhas.txt"); }

    public static synchronized List<Pin> pins(String dim) { return PINS.computeIfAbsent(dim, k -> new ArrayList<>()); }
    public static synchronized List<Link> links(String dim) { return LINKS.computeIfAbsent(dim, k -> new ArrayList<>()); }

    public static synchronized boolean hasPin(String dim, Vec3 p) {
        for (Pin x : pins(dim)) if (x.pos().distanceToSqr(p) < 1.0E-6) return true;
        return false;
    }

    public static synchronized void removePin(String dim, Vec3 p) {
        pins(dim).removeIf(x -> x.pos().distanceToSqr(p) < 1.0E-6);
        links(dim).removeIf(l -> l.a().distanceToSqr(p) < 1.0E-6 || l.b().distanceToSqr(p) < 1.0E-6);
    }

    public static synchronized boolean removeLink(String dim, Vec3 a, Vec3 b) {
        return links(dim).removeIf(l -> l.a().distanceToSqr(a) < 1.0E-6 && l.b().distanceToSqr(b) < 1.0E-6);
    }

    public static synchronized void clear(String dim) { pins(dim).clear(); links(dim).clear(); }

    public static synchronized void load(MinecraftServer s) {
        PINS.clear(); LINKS.clear();
        Path f = file(s);
        if (!Files.exists(f)) return;
        try {
            for (String line : Files.readAllLines(f)) {
                String[] p = line.trim().split(" ");
                try {
                    if (p[0].equals("P") && p.length == 9) pins(p[1]).add(new Pin(v(p, 2), v(p, 5), p[8].equals("1")));
                    else if (p[0].equals("L") && p.length == 8) links(p[1]).add(new Link(v(p, 2), v(p, 5)));
                } catch (NumberFormatException ignored) {}
            }
        } catch (IOException e) { Investigacao.LOG.error("Falha ao ler linhas", e); }
    }

    private static Vec3 v(String[] p, int i) {
        return new Vec3(Double.parseDouble(p[i]), Double.parseDouble(p[i + 1]), Double.parseDouble(p[i + 2]));
    }

    public static synchronized void save(MinecraftServer s) {
        List<String> out = new ArrayList<>();
        PINS.forEach((d, l) -> { for (Pin p : l) out.add("P " + d + " " + p.pos().x + " " + p.pos().y + " " + p.pos().z + " "
                + p.normal().x + " " + p.normal().y + " " + p.normal().z + " " + (p.start() ? 1 : 0)); });
        LINKS.forEach((d, l) -> { for (Link k : l) out.add("L " + d + " " + k.a().x + " " + k.a().y + " " + k.a().z + " "
                + k.b().x + " " + k.b().y + " " + k.b().z); });
        try { Files.write(file(s), out); } catch (IOException e) { Investigacao.LOG.error("Falha ao salvar linhas", e); }
    }
}
