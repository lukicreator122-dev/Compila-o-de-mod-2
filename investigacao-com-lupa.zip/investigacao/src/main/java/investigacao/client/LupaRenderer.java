package investigacao.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import investigacao.Investigacao;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.Sheets;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderDispatcher;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.client.model.geom.EntityModelSet;

/**
 * Desenha a lupa: corpo 3D do modelo + (em primeira pessoa) a lente com a imagem ampliada.
 * Em terceira pessoa / chão usa o modelo completo, com o vidro original.
 */
public class LupaRenderer extends BlockEntityWithoutLevelRenderer {
    public static final ResourceLocation FULL = new ResourceLocation(Investigacao.MOD_ID, "item/lupa_hand");
    public static final ResourceLocation BODY = new ResourceLocation(Investigacao.MOD_ID, "item/lupa_corpo");

    // abertura do anel (x 4.5..11.5, y 7.5..14.5, z=8), em unidades de bloco
    private static final float X0 = 4.5f / 16f, X1 = 11.5f / 16f, Y0 = 7.5f / 16f, Y1 = 14.5f / 16f, Z = 8f / 16f;

    public LupaRenderer(BlockEntityRenderDispatcher d, EntityModelSet m) { super(d, m); }

    @Override
    public void renderByItem(ItemStack stack, ItemDisplayContext ctx, PoseStack ps, MultiBufferSource buf, int light, int overlay) {
        Minecraft mc = Minecraft.getInstance();
        boolean fp = ctx.firstPerson();
        boolean lens = fp && LupaLens.ready();
        BakedModel body = mc.getModelManager().getModel(lens ? BODY : FULL);
        VertexConsumer vc = buf.getBuffer(Sheets.translucentCullBlockSheet());
        mc.getItemRenderer().renderModelLists(body, stack, light, overlay, ps, vc);
        if (lens) drawLens(ps, buf);
    }

    private static void drawLens(PoseStack ps, MultiBufferSource buf) {
        VertexConsumer vc = buf.getBuffer(RenderType.entityCutout(LupaLens.LOCATION));
        PoseStack.Pose p = ps.last();
        int l = LightTexture.FULL_BRIGHT;
        // frente (+z)
        v(vc, p, X0, Y0, Z, 0, 0, l, 1); v(vc, p, X1, Y0, Z, 1, 0, l, 1);
        v(vc, p, X1, Y1, Z, 1, 1, l, 1); v(vc, p, X0, Y1, Z, 0, 1, l, 1);
        // verso (-z), u invertido para não espelhar a imagem
        v(vc, p, X1, Y0, Z, 0, 0, l, -1); v(vc, p, X0, Y0, Z, 1, 0, l, -1);
        v(vc, p, X0, Y1, Z, 1, 1, l, -1); v(vc, p, X1, Y1, Z, 0, 1, l, -1);
    }

    private static void v(VertexConsumer vc, PoseStack.Pose p, float x, float y, float z, float u, float v, int light, float nz) {
        vc.vertex(p.pose(), x, y, z).color(255, 255, 255, 255).uv(u, v)
                .overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light).normal(p.normal(), 0f, 0f, nz).endVertex();
    }
}
