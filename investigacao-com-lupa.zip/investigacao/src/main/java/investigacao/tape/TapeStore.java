package investigacao.tape;

import investigacao.Investigacao;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.storage.LevelResource;
import net.minecraft.world.phys.Vec3;

/** Guarda as fitas/fios por dimensão em <mundo>/faixas_isolamento.txt (8 campos = formato antigo, 9 = com cor). */
public final class TapeStore {
    private static final Map<String, List<Tape>> DATA = new HashMap<>();

    private TapeStore() {}

    private static Path file(MinecraftServer s) {
        return s.getWorldPath(LevelResource.ROOT).resolve("faixas_isolamento.txt");
    }

    public static synchronized List<Tape> get(String dim) {
        return DATA.computeIfAbsent(dim, k -> new ArrayList<>());
    }

    public static synchronized void add(String dim, Tape t) { get(dim).add(t); }

    public static synchronized Tape remove(String dim, Vec3 a, Vec3 b) {
        List<Tape> l = get(dim);
        for (int i = 0; i < l.size(); i++) {
            Tape t = l.get(i);
            if (t.a().distanceToSqr(a) < 1.0E-6 && t.b().distanceToSqr(b) < 1.0E-6) return l.remove(i);
        }
        return null;
    }

    public static synchronized void clear(String dim) { get(dim).clear(); }

    public static synchronized void load(MinecraftServer s) {
        DATA.clear();
        Path f = file(s);
        if (!Files.exists(f)) return;
        try {
            for (String line : Files.readAllLines(f)) {
                String[] p = line.trim().split(" ");
                if (p.length != 8 && p.length != 9) continue;
                try {
                    Vec3 a = new Vec3(Double.parseDouble(p[1]), Double.parseDouble(p[2]), Double.parseDouble(p[3]));
                    Vec3 b = new Vec3(Double.parseDouble(p[4]), Double.parseDouble(p[5]), Double.parseDouble(p[6]));
                    int color = p.length == 9 ? Integer.parseInt(p[8]) : -1;
                    add(p[0], new Tape(a, b, p[7].equals("1"), color));
                } catch (NumberFormatException ignored) {}
            }
        } catch (IOException e) {
            Investigacao.LOG.error("Falha ao ler fitas", e);
        }
    }

    public static synchronized void save(MinecraftServer s) {
        List<String> lines = new ArrayList<>();
        DATA.forEach((dim, list) -> {
            for (Tape t : list) {
                lines.add(dim + " " + t.a().x + " " + t.a().y + " " + t.a().z + " "
                        + t.b().x + " " + t.b().y + " " + t.b().z + " " + (t.flat() ? "1" : "0") + " " + t.color());
            }
        });
        try {
            Files.write(file(s), lines);
        } catch (IOException e) {
            Investigacao.LOG.error("Falha ao salvar fitas", e);
        }
    }
}
