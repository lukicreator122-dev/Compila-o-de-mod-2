package investigacao.items;

import java.util.function.Consumer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

/** Linha Vermelha (quadro de pistas): clique nos blocos para pregar pinos ligados por linha reta. */
public class ClueLineItem extends Item {
    /** Ligados pelo cliente. */
    public static Consumer<UseOnContext> onUseBlock = c -> {};
    public static Runnable onEnd = () -> {};

    public ClueLineItem(Properties props) { super(props); }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        if (ctx.getLevel().isClientSide) onUseBlock.accept(ctx);
        return InteractionResult.SUCCESS;
    }

    /** Agachar + clicar no ar termina a corrente. */
    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide && player.isShiftKeyDown()) { onEnd.run(); return InteractionResultHolder.success(stack); }
        return InteractionResultHolder.pass(stack);
    }
}
